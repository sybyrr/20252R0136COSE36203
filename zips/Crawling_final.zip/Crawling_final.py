import time
import pandas as pd
from datetime import datetime, timedelta
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager # 로컬에서 드라이버 자동 관리

def setup_driver():
    """로컬 VSC용 크롬 드라이버 설정"""
    options = webdriver.ChromeOptions()
    options.add_argument('--headless') # 브라우저 뜨는 걸 보고 싶으면 이 줄을 주석 처리(#)하세요
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-dev-shm-usage')
    options.add_argument('window-size=1920x1080')
    options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36")
    
    # webdriver_manager를 사용해 버전에 맞는 드라이버 자동 설치 및 로드
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=options)
    return driver

# 수정된 get_starter_info 함수
def get_starter_info(driver, game_date):
    results = []
    date_str = game_date.strftime('%Y%m%d')
    url = f"https://www.koreabaseball.com/Schedule/GameCenter/Main.aspx?gameDate={date_str}"
    
    print(f"\n[{game_date.strftime('%Y-%m-%d')}] 접속 중...")
    driver.get(url)
    time.sleep(2) 

    try:
        # [수정 1] game-list-n 또는 game-list 모두 대응하도록 contains 사용
        # 제공해주신 HTML의 <li class="game-cont ..."> 요소를 찾습니다.
        game_items = driver.find_elements(By.CSS_SELECTOR, "ul[class*='game-list'] > li.game-cont")
        
        if not game_items:
            print("  -> 경기 목록을 찾을 수 없습니다.")
            return results

        print(f"  -> {len(game_items)}개의 경기 박스 발견")
        
        for idx in range(len(game_items)):
            # 요소가 변했을 수 있으므로 다시 찾기 (Stale Element 방지)
            game_items = driver.find_elements(By.CSS_SELECTOR, "ul[class*='game-list'] > li.game-cont")
            if idx >= len(game_items): break
            
            target_game = game_items[idx]
            
            # 경기 취소 여부 확인 (HTML의 staus 클래스 확인)
            try:
                status_text = target_game.find_element(By.CLASS_NAME, "staus").text.strip()
                if "취소" in status_text:
                    print(f"    경기 {idx+1}: 취소됨")
                    continue
            except:
                pass # 상태 텍스트가 없으면 진행

            print(f"    경기 {idx+1} 클릭 및 데이터 수집 시도...")
            
            # [수정 2] JavaScript로 강제 클릭 (가로 슬라이더 문제 해결)
            driver.execute_script("arguments[0].click();", target_game)
            time.sleep(1.5) # 클릭 후 하단 상세페이지 로딩 대기

            # [수정 3] 클릭 후 나타나는 하단 '경기기록' 탭 찾기
            # 화면 아래쪽에 리뷰/경기기록 탭이 동적으로 생성됩니다.
            try:
                record_tab = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable((By.XPATH, "//a[contains(text(), '리뷰')]"))
                )
                # 탭 클릭도 JS로 안전하게 처리
                driver.execute_script("arguments[0].click();", record_tab)
                time.sleep(1.5)
            except Exception as e:
                print(f"    -> '리뷰' 탭 진입 실패 (아직 경기 전이거나 데이터 없음)")
                continue

            # HTML 파싱
            soup = BeautifulSoup(driver.page_source, 'html.parser')

            # 투수 정보 추출 (이전과 동일하지만 선택자 강화)
            def extract_pitcher(table_id):
                table = soup.find('table', {'id': table_id})
                if not table: return

                # 원정/홈 구분 (ID에 따라)
                team_type = "원정" if "Away" in table_id else "홈"
                
                # 테이블 바로 위의 팀명 찾기 (h6 태그 id 활용)
                team_header_id = table_id.replace('tbl', 'lbl') # 예: tblAwayPitcher -> lblAwayPitcher
                team_header = soup.find('h6', {'id': team_header_id})
                
                if team_header:
                    # "삼성 투수" -> "삼성"만 추출
                    team_name = team_header.get_text().replace('투수', '').strip()
                else:
                    team_name = team_type

                # 행(tr) 순회
                rows = table.find('tbody').find_all('tr')
                for row in rows:
                    cols = row.find_all('td')
                    if len(cols) < 2: continue
                    
                    # 보직 확인 (두 번째 칸)
                    role = cols[1].text.strip()
                    if role == '선발':
                        p_name = cols[0].text.strip()
                        # ERA 추출 (보통 16번째 인덱스)
                        era = cols[16].text.strip() if len(cols) > 16 else "-"
                        
                        print(f"      [{team_name}] 선발: {p_name} (ERA: {era})")
                        results.append({
                            'date': game_date.strftime('%Y-%m-%d'),
                            'team': team_name,
                            'name': p_name,
                            'era': era
                        })

            # 원정/홈 투수 테이블 조회
            extract_pitcher('tblAwayPitcher')
            extract_pitcher('tblHomePitcher')

    except Exception as e:
        print(f"  에러 발생: {e}")

    return results

# 메인 실행부는 그대로 두셔도 됩니다.
if __name__ == "__main__":
    from datetime import datetime
    import pandas as pd
    
    # 드라이버는 위에서 설정한 것 그대로 사용
    driver = setup_driver() 
    
    # 테스트용 날짜 (스크린샷에 있는 날짜로 테스트 추천)
    start_date = datetime(2025, 11, 15) 
    end_date = datetime(2025, 11, 16)
    
    all_data = []
    current = start_date
    while current <= end_date:
        data = get_starter_info(driver, current)
        all_data.extend(data)
        current += timedelta(days=1)
        
    driver.quit()
    
    if all_data:
        df = pd.DataFrame(all_data)
        print("\n=== 결과 ===")
        print(df)
        df.to_csv("kbo_starters_fixed.csv", index=False, encoding="utf-8-sig")